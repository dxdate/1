import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'doronichi-tasting-app-2025'
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or \
        'sqlite:///doronichi_tasting.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    # Настройки для разработки
    DEBUG = True
    HOST = '0.0.0.0'
    PORT = 5000
