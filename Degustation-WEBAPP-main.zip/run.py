
"""
Скрипт запуска веб-приложения Дороничи для дегустаций
"""

import os
import sys
import socket
from app import app, create_tables

def main():
    """Основная функция запуска приложения"""
    print("=" * 60)
    print("🍽️  Дороничи - Веб-приложение для дегустаций")
    print("=" * 60)
    
    # Проверяем наличие необходимых файлов
    required_files = ['app.py', 'config.py', 'requirements.txt']
    missing_files = [f for f in required_files if not os.path.exists(f)]
    
    if missing_files:
        print(f"❌ Отсутствуют необходимые файлы: {', '.join(missing_files)}")
        sys.exit(1)
    
    print("✅ Все необходимые файлы найдены")
    
    # Создаем таблицы базы данных
    print("📊 Создание таблиц базы данных...")
    try:
        create_tables()
        print("✅ Таблицы базы данных созданы успешно")
    except Exception as e:
        print(f"❌ Ошибка создания таблиц: {e}")
        print("💡 Убедитесь, что SQL Server запущен и база данных доступна")
        sys.exit(1)
    
    # Запускаем приложение
    # Определим локальный IP для доступа с телефона в сети
    def get_lan_ip():
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except Exception:
            return "127.0.0.1"

    lan_ip = get_lan_ip()

    print("\n🚀 Запуск веб-приложения...")
    print("📍 Локально:   http://localhost:5000")
    print(f"📶 В сети LAN: http://{lan_ip}:5000  (для телефона)")
    print(f"🔑 Админ-панель: http://{lan_ip}:5000/admin/login")
    print("👤 Логин: admin / Пароль: admin123")
    print("\n" + "=" * 60)
    print("Нажмите Ctrl+C для остановки сервера")
    print("=" * 60)
    
    try:
        app.run(
            host=app.config.get('HOST', '0.0.0.0'),
            port=app.config.get('PORT', 5000),
            debug=app.config.get('DEBUG', True)
        )
    except KeyboardInterrupt:
        print("\n\n👋 Сервер остановлен. До свидания!")
    except Exception as e:
        print(f"\n❌ Ошибка запуска сервера: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main()
