from app import create_tables, import_from_csv
import sys

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print('Usage: python import_csv.py "Путь/к/файлу.csv"')
        sys.exit(1)
    path = sys.argv[1]
    create_tables()
    import_from_csv(path)
    print('Импорт завершен успешно')
