from flask import Flask, render_template, request, jsonify, redirect, url_for, session, flash, abort, send_file
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timedelta
import uuid
import qrcode
import io
import base64
import json
import os
import csv
import re
from sqlalchemy import text
import socket
from urllib.parse import urlparse, urlunparse
from config import Config
from functools import wraps
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from docx import Document
from docx.shared import Pt, Inches, RGBColor, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH

app = Flask(__name__)
app.config.from_object(Config)

db = SQLAlchemy(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'admin_login'

# Модели базы данных
class Admin(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(120), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)
    role = db.Column(db.String(20), default='viewer')  # superadmin | manager | viewer

class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    category = db.Column(db.String(100))
    image_url = db.Column(db.String(500))
    weight_kg = db.Column(db.Float)  # Вес упаковки из CSV, если указан
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)

class TastingSession(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    admin_id = db.Column(db.Integer, db.ForeignKey('admin.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)
    access_code = db.Column(db.String(50), unique=True, nullable=False)
    qr_code_url = db.Column(db.String(500))
    tasting_type = db.Column(db.String(20), default='simplified')  # simplified | full
    criteria_json = db.Column(db.Text)  # JSON-массив критериев
    task_origin = db.Column(db.String(255))  # Происхождение задачи/задача
    ended_at = db.Column(db.DateTime)
    
    # Связи
    admin = db.relationship('Admin', backref=db.backref('tasting_sessions', lazy=True))
    products = db.relationship('TastingProduct', backref='tasting_session', lazy=True, cascade='all, delete-orphan')
    responses = db.relationship('TastingResponse', backref='tasting_session', lazy=True, cascade='all, delete-orphan')

class TastingProduct(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    tasting_session_id = db.Column(db.Integer, db.ForeignKey('tasting_session.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    order_index = db.Column(db.Integer, nullable=False)
    photo_url = db.Column(db.String(500))
    
    # Связи
    product = db.relationship('Product', backref=db.backref('tasting_products', lazy=True))

class TastingResponse(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    tasting_session_id = db.Column(db.Integer, db.ForeignKey('tasting_session.id'), nullable=False)
    session_identifier = db.Column(db.String(100), nullable=False)  # Уникальный идентификатор сессии пользователя
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    rating = db.Column(db.Integer)  # legacy поле для упрощенной дегустации
    ratings_json = db.Column(db.Text)  # JSON: { "taste": 5, "color": 4, ... }
    comment = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Связи
    product = db.relationship('Product', backref=db.backref('tasting_responses', lazy=True))

# Шаблоны происхождения задач
class TaskOriginTemplate(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), unique=True, nullable=False)
    usage_count = db.Column(db.Integer, default=0)

# Подсказки комментариев
class CommentSuggestion(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    text = db.Column(db.String(255), unique=True, nullable=False)
    usage_count = db.Column(db.Integer, default=0)

@login_manager.user_loader
def load_user(user_id):
    return Admin.query.get(int(user_id))

# Декоратор проверки ролей
def roles_required(*roles):
    def decorator(fn):
        @wraps(fn)
        def wrapped(*args, **kwargs):
            if not current_user.is_authenticated:
                abort(401)
            if current_user.role not in roles:
                abort(403)
            return fn(*args, **kwargs)
        return wrapped
    return decorator

# Контекстные флаги для ролей в шаблонах
@app.context_processor
def inject_role_flags():
    is_superadmin = (current_user.is_authenticated and getattr(current_user, 'role', None) == 'superadmin')
    is_manager = (current_user.is_authenticated and getattr(current_user, 'role', None) == 'manager')
    is_viewer = (current_user.is_authenticated and getattr(current_user, 'role', None) == 'viewer')
    return {
        'is_superadmin': is_superadmin,
        'is_manager': is_manager,
        'is_viewer': is_viewer,
    }

# Корень сайта перенаправляем в админ-панель (главная страница отключена)
@app.route('/')
def root_redirect():
    return redirect(url_for('admin_login'))

# Страница дегустации
@app.route('/tasting/<access_code>')
def tasting_page(access_code):
    tasting_session = TastingSession.query.filter_by(access_code=access_code, is_active=True).first()
    if not tasting_session:
        flash('Сессия дегустации не найдена или неактивна', 'error')
        return redirect(url_for('admin_login'))
    
    # Получаем продукты в правильном порядке
    tasting_products = TastingProduct.query.filter_by(tasting_session_id=tasting_session.id).order_by(TastingProduct.order_index).all()
    products_payload = []
    for tp in tasting_products:
        p = tp.product
        products_payload.append({
            'id': p.id,
            'name': p.name,
            'description': p.description,
            'category': p.category,
            'image_url': p.image_url
        })
    # Критерии
    if tasting_session.criteria_json:
        criteria = json.loads(tasting_session.criteria_json)
    else:
        criteria = ['taste']
    
    # Подсказки для комментариев (топ-20)
    comment_suggestions = CommentSuggestion.query.order_by(CommentSuggestion.usage_count.desc()).limit(20).all()
    
    return render_template('tasting.html', tasting_session=tasting_session, products=products_payload, criteria=criteria, comment_suggestions=comment_suggestions, hide_auth_links=True)

# API для сохранения ответов дегустации
@app.route('/api/tasting/<access_code>/response', methods=['POST'])
def save_tasting_response(access_code):
    tasting_session = TastingSession.query.filter_by(access_code=access_code, is_active=True).first()
    if not tasting_session:
        return jsonify({'error': 'Сессия не найдена'}), 404
    
    data = request.get_json()
    session_id = data.get('session_id')
    product_id = data.get('product_id')
    rating = data.get('rating')  # legacy поддержка
    ratings = data.get('ratings')  # dict критерий->оценка
    comment = data.get('comment', '')
    
    if not session_id or not product_id:
        return jsonify({'error': 'Недостаточно данных'}), 400
    
    # Ищем существующий ответ или создаем новый
    response = TastingResponse.query.filter_by(
        tasting_session_id=tasting_session.id,
        session_identifier=session_id,
        product_id=product_id
    ).first()
    
    if response:
        # Обновляем оценки
        if ratings is not None:
            response.ratings_json = json.dumps(ratings, ensure_ascii=False)
            response.rating = ratings.get('taste') if isinstance(ratings, dict) else None
        else:
            response.rating = rating
        response.comment = comment
        response.updated_at = datetime.utcnow()
    else:
        response = TastingResponse(
            tasting_session_id=tasting_session.id,
            session_identifier=session_id,
            product_id=product_id,
            rating=ratings.get('taste') if isinstance(ratings, dict) else rating,
            ratings_json=json.dumps(ratings, ensure_ascii=False) if ratings is not None else None,
            comment=comment
        )
        db.session.add(response)
    
    try:
        db.session.commit()
        return jsonify({'success': True, 'message': 'Ответ сохранен'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': 'Ошибка сохранения'}), 500

# API для получения ответов дегустации
@app.route('/api/tasting/<access_code>/responses/<session_id>')
def get_tasting_responses(access_code, session_id):
    tasting_session = TastingSession.query.filter_by(access_code=access_code, is_active=True).first()
    if not tasting_session:
        return jsonify({'error': 'Сессия не найдена'}), 404
    
    responses = TastingResponse.query.filter_by(
        tasting_session_id=tasting_session.id,
        session_identifier=session_id
    ).all()
    
    result = {}
    for response in responses:
        item = {
            'comment': response.comment
        }
        if response.ratings_json:
            try:
                item['ratings'] = json.loads(response.ratings_json)
            except Exception:
                item['ratings'] = {}
        else:
            item['ratings'] = {'taste': response.rating} if response.rating is not None else {}
        result[response.product_id] = item
    
    return jsonify(result)

# Вспомогательные функции для LAN URL
def _get_lan_ip() -> str:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"

def _public_tasting_url(access_code: str) -> str:
    try:
        link = url_for('tasting_page', access_code=access_code, _external=True)
    except Exception:
        link = f"{request.url_root}tasting/{access_code}"
    try:
        parsed = urlparse(link)
        host = parsed.hostname or ''
        if host in ('localhost', '127.0.0.1', '::1'):
            lan_ip = _get_lan_ip()
            netloc = f"{lan_ip}:{parsed.port}" if parsed.port else lan_ip
            link = urlunparse((parsed.scheme, netloc, parsed.path, parsed.params, parsed.query, parsed.fragment))
    except Exception:
        pass
    return link

# API для завершения дегустации
@app.route('/api/tasting/<access_code>/complete', methods=['POST'])
def complete_tasting(access_code):
    tasting_session = TastingSession.query.filter_by(access_code=access_code, is_active=True).first()
    if not tasting_session:
        return jsonify({'error': 'Сессия не найдена'}), 404
    
    data = request.get_json()
    session_id = data.get('session_id')
    
    if not session_id:
        return jsonify({'error': 'Недостаточно данных'}), 400
    
    # Здесь можно добавить дополнительную логику завершения
    return jsonify({'success': True, 'message': 'Дегустация завершена'})

# Админ панель - вход
@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        admin = Admin.query.filter_by(username=username).first()
        
        if admin and check_password_hash(admin.password_hash, password):
            login_user(admin)
            return redirect(url_for('admin_dashboard'))
        else:
            flash('Неверное имя пользователя или пароль', 'error')
    
    return render_template('admin/login.html')

# Админ панель - регистрация
@app.route('/admin/register', methods=['GET', 'POST'])
def admin_register():
    # Регистрация доступна, если нет ни одного пользователя, либо только для суперадмина
    total_users = Admin.query.count()
    if total_users > 0 and (not current_user.is_authenticated or current_user.role != 'superadmin'):
        abort(403)
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        password2 = request.form['password2']

        if not username or not email or not password:
            flash('Заполните все обязательные поля', 'error')
            return redirect(url_for('admin_register'))
        if password != password2:
            flash('Пароли не совпадают', 'error')
            return redirect(url_for('admin_register'))
        if Admin.query.filter((Admin.username==username) | (Admin.email==email)).first():
            flash('Пользователь с таким именем или e-mail уже существует', 'error')
            return redirect(url_for('admin_register'))

        admin = Admin(
            username=username,
            email=email,
            password_hash=generate_password_hash(password),
            role='superadmin' if total_users == 0 else 'viewer'
        )
        try:
            db.session.add(admin)
            db.session.commit()
            flash('Администратор зарегистрирован. Войдите под своей учетной записью.', 'success')
            return redirect(url_for('admin_login'))
        except Exception:
            db.session.rollback()
            flash('Ошибка регистрации', 'error')
    return render_template('admin/register.html')

# Админ панель - выход
@app.route('/admin/logout')
@login_required
def admin_logout():
    logout_user()
    return redirect(url_for('admin_login'))

# Админ панель - главная
@app.route('/admin')
@login_required
def admin_dashboard():
    # Просмотрщик/менеджер/суперадмин видят все дегустации
    tasting_sessions = TastingSession.query.order_by(TastingSession.created_at.desc()).all()
    products_count = Product.query.filter_by(is_active=True).count()
    
    return render_template('admin/dashboard.html', 
                         tasting_sessions=tasting_sessions, 
                         products_count=products_count)

# Админ панель - создание дегустации
@app.route('/admin/tasting/create', methods=['GET', 'POST'])
@login_required
@roles_required('superadmin', 'manager')
def create_tasting():
    if request.method == 'POST':
        name = request.form['name']
        description = request.form['description']
        product_ids = request.form.getlist('products')
        tasting_type = request.form.get('tasting_type', 'simplified')
        task_origin = request.form.get('task_origin')
        
        if not name or not product_ids:
            flash('Заполните все обязательные поля', 'error')
            return redirect(url_for('create_tasting'))
        
        # Создаем уникальный код доступа
        access_code = str(uuid.uuid4())[:8]
        
        # Создаем сессию дегустации
        tasting_session = TastingSession(
            name=name,
            description=description,
            admin_id=current_user.id,
            access_code=access_code,
            tasting_type=tasting_type,
            criteria_json=json.dumps(['taste'] if tasting_type=='simplified' else ['taste','color','smell','texture'], ensure_ascii=False),
            task_origin=task_origin
        )
        db.session.add(tasting_session)
        db.session.flush()  # Получаем ID
        
        # Добавляем продукты в правильном порядке
        for index, product_id in enumerate(product_ids):
            tasting_product = TastingProduct(
                tasting_session_id=tasting_session.id,
                product_id=int(product_id),
                order_index=index
            )
            db.session.add(tasting_product)
        
        try:
            db.session.commit()
            # Обновим/создадим шаблон происхождения задачи
            if task_origin:
                tpl = TaskOriginTemplate.query.filter_by(name=task_origin).first()
                if not tpl:
                    tpl = TaskOriginTemplate(name=task_origin, usage_count=1)
                    db.session.add(tpl)
                else:
                    tpl.usage_count = (tpl.usage_count or 0) + 1
                db.session.commit()
            
            # Генерируем QR-код
            qr_url = generate_qr_code(access_code)
            tasting_session.qr_code_url = qr_url
            db.session.commit()
            
            flash('Дегустация успешно создана!', 'success')
            return redirect(url_for('view_tasting', id=tasting_session.id))
        except Exception as e:
            db.session.rollback()
            flash('Ошибка при создании дегустации', 'error')
    
    products = Product.query.filter_by(is_active=True).all()
    task_origins = TaskOriginTemplate.query.order_by(TaskOriginTemplate.usage_count.desc()).limit(30).all()
    return render_template('admin/create_tasting.html', products=products, task_origins=task_origins)

# Админ панель - редактирование дегустации
@app.route('/admin/tasting/<int:id>/edit', methods=['GET', 'POST'])
@login_required
@roles_required('superadmin', 'manager')
def edit_tasting(id):
    tasting_session = TastingSession.query.filter_by(id=id).first()
    if not tasting_session:
        flash('Дегустация не найдена', 'error')
        return redirect(url_for('admin_dashboard'))

    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        description = request.form.get('description', '').strip()
        task_origin = request.form.get('task_origin', '').strip()

        if not name:
            flash('Введите название дегустации', 'error')
            return redirect(url_for('edit_tasting', id=id))

        # Обновляем только базовые поля (без изменения состава и типа)
        tasting_session.name = name
        tasting_session.description = description
        tasting_session.task_origin = task_origin

        try:
            db.session.commit()
            # Обновим/создадим шаблон происхождения задачи
            if task_origin:
                tpl = TaskOriginTemplate.query.filter_by(name=task_origin).first()
                if not tpl:
                    tpl = TaskOriginTemplate(name=task_origin, usage_count=1)
                    db.session.add(tpl)
                else:
                    tpl.usage_count = (tpl.usage_count or 0) + 1
                db.session.commit()

            flash('Дегустация обновлена', 'success')
            return redirect(url_for('view_tasting', id=id))
        except Exception:
            db.session.rollback()
            flash('Не удалось сохранить изменения', 'error')
            return redirect(url_for('edit_tasting', id=id))

    # GET - форма редактирования
    task_origins = TaskOriginTemplate.query.order_by(TaskOriginTemplate.usage_count.desc()).limit(30).all()
    return render_template(
        'admin/edit_tasting.html',
        tasting_session=tasting_session,
        task_origins=task_origins
    )

# Админ панель - просмотр дегустации
@app.route('/admin/tasting/<int:id>')
@login_required
def view_tasting(id):
    tasting_session = TastingSession.query.filter_by(id=id).first()
    if not tasting_session:
        flash('Дегустация не найдена', 'error')
        return redirect(url_for('admin_dashboard'))
    
    # Получаем продукты
    tasting_products = TastingProduct.query.filter_by(tasting_session_id=tasting_session.id).order_by(TastingProduct.order_index).all()
    products = [tp.product for tp in tasting_products]
    
    # Преобразуем продукты в словари для JSON сериализации
    products_json = []
    for p in products:
        products_json.append({
            'id': p.id,
            'name': p.name,
            'category': p.category,
            'weight_kg': p.weight_kg,
            'image_url': p.image_url
        })
    
    # Получаем статистику ответов
    responses = TastingResponse.query.filter_by(tasting_session_id=tasting_session.id).all()
    
    # Обновляем QR на основе LAN URL (на случай, если ранее был localhost)
    try:
        new_qr = generate_qr_code(tasting_session.access_code)
        if tasting_session.qr_code_url != new_qr:
            tasting_session.qr_code_url = new_qr
            db.session.commit()
    except Exception:
        db.session.rollback()

    return render_template('admin/view_tasting.html', 
                         tasting_session=tasting_session, 
                         products=products,
                         products_json=products_json,
                         tasting_products=tasting_products,
                         responses=responses)

# Админ панель - управление продуктами
@app.route('/admin/products')
@login_required
def manage_products():
    products = Product.query.filter_by(is_active=True).all()
    return render_template('admin/products.html', products=products)

# Добавление продуктов вручную отключено
@app.route('/admin/products/add', methods=['GET', 'POST'])
@login_required
@roles_required('superadmin', 'manager')
def add_product():
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        category = request.form.get('category', '').strip()
        description = request.form.get('description', '').strip()
        image_url = request.form.get('image_url', '').strip()
        if not name:
            flash('Укажите название продукта', 'error')
            return redirect(url_for('add_product'))
        try:
            existing = Product.query.filter_by(name=name).first()
            if existing:
                flash('Продукт с таким названием уже существует', 'error')
                return redirect(url_for('add_product'))
            p = Product(name=name, category=category or None, description=description or None, image_url=image_url or None)
            db.session.add(p)
            db.session.commit()
            flash('Продукт добавлен', 'success')
            return redirect(url_for('manage_products'))
        except Exception:
            db.session.rollback()
            flash('Ошибка при добавлении продукта', 'error')
    return render_template('admin/add_product.html')

# Загрузка фото продукта в рамках дегустации
@app.route('/admin/tasting/<int:id>/upload_photo/<int:tasting_product_id>', methods=['POST'])
@login_required
@roles_required('superadmin', 'manager')
def upload_tasting_product_photo(id, tasting_product_id):
    tasting_session = TastingSession.query.filter_by(id=id).first()
    if not tasting_session:
        flash('Дегустация не найдена', 'error')
        return redirect(url_for('admin_dashboard'))

    tp = TastingProduct.query.filter_by(id=tasting_product_id, tasting_session_id=tasting_session.id).first()
    if not tp:
        flash('Продукт дегустации не найден', 'error')
        return redirect(url_for('view_tasting', id=id))

    file = request.files.get('photo')
    if not file or file.filename == '':
        flash('Файл не выбран', 'error')
        return redirect(url_for('view_tasting', id=id))

    upload_dir = os.path.join('static', 'uploads')
    os.makedirs(upload_dir, exist_ok=True)
    filename = f"t_{id}_p_{tasting_product_id}_{int(datetime.utcnow().timestamp())}.png"
    save_path = os.path.join(upload_dir, filename)
    try:
        file.save(save_path)
        tp.photo_url = '/' + save_path.replace('\\', '/')
        db.session.commit()
        flash('Фото загружено', 'success')
    except Exception:
        db.session.rollback()
        flash('Ошибка загрузки фото', 'error')
    return redirect(url_for('view_tasting', id=id))

# Детали и статистика по продукту
@app.route('/admin/products/<int:product_id>/details')
@login_required
def product_details(product_id):
    product = Product.query.filter_by(id=product_id, is_active=True).first()
    if not product:
        return jsonify({'error': 'Продукт не найден'}), 404

    responses = TastingResponse.query.filter_by(product_id=product_id).all()
    # Сессии для названий
    session_ids = list({r.tasting_session_id for r in responses})
    sessions_map = {s.id: s for s in TastingSession.query.filter(TastingSession.id.in_(session_ids)).all()} if session_ids else {}

    criteria_keys = ['taste', 'color', 'smell', 'texture']
    totals = {k: {'sum': 0.0, 'count': 0} for k in criteria_keys}

    tastings = {}
    comments = []
    for r in responses:
        ratings = {}
        if r.ratings_json:
            try:
                ratings = json.loads(r.ratings_json)
            except Exception:
                ratings = {}
        if not ratings and r.rating is not None:
            ratings = {'taste': r.rating}

        for k in criteria_keys:
            v = ratings.get(k)
            if isinstance(v, (int, float)):
                totals[k]['sum'] += float(v)
                totals[k]['count'] += 1

        # Группируем по сессиям
        s_id = r.tasting_session_id
        if s_id not in tastings:
            tastings[s_id] = {
                'name': sessions_map.get(s_id).name if s_id in sessions_map else f'Session {s_id}',
                'created_at': sessions_map.get(s_id).created_at.isoformat() if s_id in sessions_map else None,
                'totals': {k: {'sum': 0.0, 'count': 0} for k in criteria_keys},
                'count': 0
            }
        for k in criteria_keys:
            v = ratings.get(k)
            if isinstance(v, (int, float)):
                tastings[s_id]['totals'][k]['sum'] += float(v)
                tastings[s_id]['totals'][k]['count'] += 1
        tastings[s_id]['count'] += 1

        if r.comment:
            comments.append({
                'tasting_session': tastings[s_id]['name'],
                'created_at': r.created_at.isoformat(),
                'comment': r.comment
            })

    def avg(obj):
        return {k: (round(v['sum'] / v['count'], 2) if v['count'] else None) for k, v in obj.items()}

    overall = avg(totals)
    tastings_list = []
    for s_id, data in sorted(tastings.items(), key=lambda x: x[1]['created_at'] or ''):
        tastings_list.append({
            'name': data['name'],
            'created_at': data['created_at'],
            'count': data['count'],
            'avg': avg(data['totals'])
        })

    result = {
        'product': {
            'id': product.id,
            'name': product.name,
            'category': product.category,
            'weight_kg': product.weight_kg,
            'description': product.description,
            'image_url': product.image_url
        },
        'overall_avg': overall,
        'total_responses': len(responses),
        'tastings': tastings_list,
        'comments': sorted(comments, key=lambda x: x['created_at'] or '', reverse=True)[:50]
    }
    return jsonify(result)

# API для получения результатов дегустации (для автообновления)
@app.route('/admin/api/tasting/<int:id>/results')
@login_required
def admin_tasting_results(id):
    tasting_session = TastingSession.query.filter_by(id=id).first()
    if not tasting_session:
        return jsonify({'error': 'Дегустация не найдена'}), 404
    
    tasting_products = TastingProduct.query.filter_by(tasting_session_id=id).order_by(TastingProduct.order_index).all()
    all_responses = TastingResponse.query.filter_by(tasting_session_id=id).all()
    
    results = []
    for tp in tasting_products:
        product = tp.product
        product_responses = [r for r in all_responses if r.product_id == product.id]
        
        if not product_responses:
            continue
        
        # Рассчитываем средние оценки
        taste_scores = []
        for resp in product_responses:
            ratings = {}
            if resp.ratings_json:
                try:
                    ratings = json.loads(resp.ratings_json)
                except Exception:
                    pass
            if not ratings and resp.rating is not None:
                ratings = {'taste': resp.rating}
            
            if 'taste' in ratings and ratings['taste'] is not None:
                taste_scores.append(float(ratings['taste']))
        
        avg_rating = sum(taste_scores) / len(taste_scores) if taste_scores else 0
        comment_count = len([r for r in product_responses if r.comment and r.comment.strip()])
        
        results.append({
            'product_id': product.id,
            'avg_rating': round(avg_rating, 1),
            'response_count': len(product_responses),
            'comment_count': comment_count
        })
    
    return jsonify(results)

# Реальное время: ответы/комментарии по дегустации
@app.route('/admin/api/tasting/<int:id>/responses')
@login_required
def admin_tasting_responses(id):
    tasting_session = TastingSession.query.filter_by(id=id).first()
    if not tasting_session:
        return jsonify({'error': 'Дегустация не найдена'}), 404

    since = request.args.get('since')
    product_id = request.args.get('product_id', type=int)
    query = TastingResponse.query.filter_by(tasting_session_id=id)
    if product_id:
        query = query.filter(TastingResponse.product_id == product_id)
    if since:
        try:
            dt = datetime.fromisoformat(since)
            query = query.filter(TastingResponse.updated_at >= dt)
        except Exception:
            pass
    responses = query.order_by(TastingResponse.updated_at.desc()).limit(200).all()

    result = []
    for r in responses:
        ratings = {}
        if r.ratings_json:
            try:
                ratings = json.loads(r.ratings_json)
            except Exception:
                ratings = {}
        if not ratings and r.rating is not None:
            ratings = {'taste': r.rating}
        result.append({
            'product_id': r.product_id,
            'product_name': r.product.name if r.product else None,
            'ratings': ratings,
            'comment': r.comment,
            'created_at': r.created_at.isoformat(),
            'updated_at': r.updated_at.isoformat() if r.updated_at else None
        })
    return jsonify(result)

# Завершить дегустацию админом
@app.route('/admin/tasting/<int:id>/close', methods=['POST'])
@login_required
@roles_required('superadmin', 'manager')
def close_tasting(id):
    tasting_session = TastingSession.query.filter_by(id=id).first()
    if not tasting_session:
        flash('Дегустация не найдена', 'error')
        return redirect(url_for('admin_dashboard'))
    tasting_session.is_active = False
    tasting_session.ended_at = datetime.utcnow()
    try:
        db.session.commit()
        flash('Дегустация завершена', 'success')
    except Exception:
        db.session.rollback()
        flash('Не удалось завершить дегустацию', 'error')
    return redirect(url_for('view_tasting', id=id))

# Экспорт отчета в Excel
@app.route('/admin/tasting/<int:id>/export_excel')
@login_required
def export_tasting_excel(id):
    tasting_session = TastingSession.query.filter_by(id=id).first()
    if not tasting_session:
        flash('Дегустация не найдена', 'error')
        return redirect(url_for('admin_dashboard'))
    
    # Получаем продукты в порядке дегустации
    tasting_products = TastingProduct.query.filter_by(tasting_session_id=tasting_session.id).order_by(TastingProduct.order_index).all()
    
    # Получаем все ответы по дегустации
    all_responses = TastingResponse.query.filter_by(tasting_session_id=tasting_session.id).all()
    
    # Создаем словарь для группировки ответов по продуктам
    product_responses = {}
    for resp in all_responses:
        if resp.product_id not in product_responses:
            product_responses[resp.product_id] = []
        product_responses[resp.product_id].append(resp)
    
    # Создаем Excel книгу
    wb = Workbook()
    ws = wb.active
    ws.title = "Дегустация"
    
    # Заголовок с датой и названием
    date_str = tasting_session.created_at.strftime('%d.%m.%Y') if tasting_session.created_at else ''
    ws.merge_cells('A1:Z1')
    header_cell = ws['A1']
    # Если есть описание, добавляем его к заголовку
    if tasting_session.description:
        header_text = f'Дата дегустации: {date_str} {tasting_session.name} {tasting_session.description}'
    else:
        header_text = f'Дата дегустации: {date_str} {tasting_session.name}'
    header_cell.value = header_text
    header_cell.font = Font(bold=True, size=12)
    header_cell.alignment = Alignment(horizontal='left')
    
    # Проверяем наличие данных "Лоток" (для примера, можно добавить поле в БД)
    has_tray_data = False  # Пока оставляем False, можно добавить проверку
    
    # Заголовки таблицы
    headers = ['№', 'Название', 'Происхождение задачи/задача']
    if has_tray_data:
        headers.append('Лоток')
    headers.extend(['ТМ', 'Вес упак, кг', 'Вкус', 'Цвет', 'Запах', 'Консистенция', 'Ср. балл', 'Комментарии', 'Решения'])
    
    # Стиль границ
    thin_border = Border(
        left=Side(style='thin', color='000000'),
        right=Side(style='thin', color='000000'),
        top=Side(style='thin', color='000000'),
        bottom=Side(style='thin', color='000000')
    )
    
    # Заголовки таблицы
    for col_idx, header in enumerate(headers, start=1):
        cell = ws.cell(row=3, column=col_idx, value=header)
        cell.font = Font(bold=True)
        cell.alignment = Alignment(horizontal='center', vertical='center')
        cell.fill = PatternFill(start_color='E0E0E0', end_color='E0E0E0', fill_type='solid')
        cell.border = thin_border
    
    # Заполняем данные по продуктам
    row_num = 4
    for idx, tp in enumerate(tasting_products, start=1):
        product = tp.product
        responses = product_responses.get(product.id, [])
        
        # Рассчитываем средние оценки
        taste_scores = []
        color_scores = []
        smell_scores = []
        texture_scores = []
        comments_list = []
        
        for resp in responses:
            ratings = {}
            if resp.ratings_json:
                try:
                    ratings = json.loads(resp.ratings_json)
                except Exception:
                    pass
            if not ratings and resp.rating is not None:
                ratings = {'taste': resp.rating}
            
            if 'taste' in ratings and ratings['taste'] is not None:
                taste_scores.append(float(ratings['taste']))
            if 'color' in ratings and ratings['color'] is not None:
                color_scores.append(float(ratings['color']))
            if 'smell' in ratings and ratings['smell'] is not None:
                smell_scores.append(float(ratings['smell']))
            if 'texture' in ratings and ratings['texture'] is not None:
                texture_scores.append(float(ratings['texture']))
            
            if resp.comment and resp.comment.strip():
                comments_list.append(resp.comment.strip())
        
        # Средние значения
        avg_taste = round(sum(taste_scores) / len(taste_scores), 2) if taste_scores else None
        avg_color = round(sum(color_scores) / len(color_scores), 2) if color_scores else None
        avg_smell = round(sum(smell_scores) / len(smell_scores), 2) if smell_scores else None
        avg_texture = round(sum(texture_scores) / len(texture_scores), 2) if texture_scores else None
        
        # Средний балл
        criteria_avgs = [v for v in [avg_taste, avg_color, avg_smell, avg_texture] if v is not None]
        avg_total = round(sum(criteria_avgs) / len(criteria_avgs), 2) if criteria_avgs else None
        
        # Объединяем комментарии
        comments_text = '; '.join(comments_list) if comments_list else ''
        
        # Заполняем строку
        col_idx = 1
        ws.cell(row=row_num, column=col_idx, value=idx).alignment = Alignment(horizontal='center', vertical='center')
        ws.cell(row=row_num, column=col_idx).border = thin_border
        col_idx += 1
        
        ws.cell(row=row_num, column=col_idx, value=product.name).alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        ws.cell(row=row_num, column=col_idx).border = thin_border
        col_idx += 1
        
        ws.cell(row=row_num, column=col_idx, value=tasting_session.task_origin or '').alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        ws.cell(row=row_num, column=col_idx).border = thin_border
        col_idx += 1
        
        if has_tray_data:
            ws.cell(row=row_num, column=col_idx, value='').alignment = Alignment(horizontal='center', vertical='center')
            ws.cell(row=row_num, column=col_idx).border = thin_border
            col_idx += 1
        
        ws.cell(row=row_num, column=col_idx, value='').alignment = Alignment(horizontal='center', vertical='center')
        ws.cell(row=row_num, column=col_idx).border = thin_border
        col_idx += 1
        
        weight_val = ''
        if product.weight_kg:
            weight_str = f"{product.weight_kg:.2f}".replace('.', ',')
            weight_val = weight_str
        ws.cell(row=row_num, column=col_idx, value=weight_val).alignment = Alignment(horizontal='center', vertical='center')
        ws.cell(row=row_num, column=col_idx).border = thin_border
        col_idx += 1
        
        taste_val = f"{avg_taste:.2f}".replace('.', ',') if avg_taste is not None else ''
        ws.cell(row=row_num, column=col_idx, value=taste_val).alignment = Alignment(horizontal='center', vertical='center')
        ws.cell(row=row_num, column=col_idx).border = thin_border
        col_idx += 1
        
        color_val = f"{avg_color:.2f}".replace('.', ',') if avg_color is not None else ''
        ws.cell(row=row_num, column=col_idx, value=color_val).alignment = Alignment(horizontal='center', vertical='center')
        ws.cell(row=row_num, column=col_idx).border = thin_border
        col_idx += 1
        
        smell_val = f"{avg_smell:.2f}".replace('.', ',') if avg_smell is not None else ''
        ws.cell(row=row_num, column=col_idx, value=smell_val).alignment = Alignment(horizontal='center', vertical='center')
        ws.cell(row=row_num, column=col_idx).border = thin_border
        col_idx += 1
        
        texture_val = f"{avg_texture:.2f}".replace('.', ',') if avg_texture is not None else ''
        ws.cell(row=row_num, column=col_idx, value=texture_val).alignment = Alignment(horizontal='center', vertical='center')
        ws.cell(row=row_num, column=col_idx).border = thin_border
        col_idx += 1
        
        total_val = f"{avg_total:.2f}".replace('.', ',') if avg_total is not None else ''
        ws.cell(row=row_num, column=col_idx, value=total_val).alignment = Alignment(horizontal='center', vertical='center')
        ws.cell(row=row_num, column=col_idx).border = thin_border
        col_idx += 1
        
        ws.cell(row=row_num, column=col_idx, value=comments_text).alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        ws.cell(row=row_num, column=col_idx).border = thin_border
        col_idx += 1
        
        ws.cell(row=row_num, column=col_idx, value='').alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        ws.cell(row=row_num, column=col_idx).border = thin_border
        
        row_num += 1
    
    # Настройка ширины столбцов (увеличиваем размеры)
    ws.column_dimensions['A'].width = 8
    ws.column_dimensions['B'].width = 45
    ws.column_dimensions['C'].width = 35
    if has_tray_data:
        ws.column_dimensions['D'].width = 18
        start_tm = 'E'
    else:
        start_tm = 'D'
    ws.column_dimensions[start_tm].width = 12
    ws.column_dimensions[chr(ord(start_tm) + 1)].width = 15
    ws.column_dimensions[chr(ord(start_tm) + 2)].width = 12
    ws.column_dimensions[chr(ord(start_tm) + 3)].width = 12
    ws.column_dimensions[chr(ord(start_tm) + 4)].width = 12
    ws.column_dimensions[chr(ord(start_tm) + 5)].width = 18
    ws.column_dimensions[chr(ord(start_tm) + 6)].width = 12
    ws.column_dimensions[chr(ord(start_tm) + 7)].width = 55
    ws.column_dimensions[chr(ord(start_tm) + 8)].width = 55
    
    # Сохраняем в память
    output = io.BytesIO()
    wb.save(output)
    output.seek(0)
    
    # Имя файла
    filename = f"Дегустация_{tasting_session.name}_{date_str.replace('.', '_')}.xlsx"
    filename = re.sub(r'[<>:"/\\|?*]', '_', filename)  # Заменяем недопустимые символы
    
    return send_file(output, mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 
                     as_attachment=True, download_name=filename)

# Экспорт отчета в Word
@app.route('/admin/tasting/<int:id>/export_word')
@login_required
def export_tasting_word(id):
    tasting_session = TastingSession.query.filter_by(id=id).first()
    if not tasting_session:
        flash('Дегустация не найдена', 'error')
        return redirect(url_for('admin_dashboard'))
    
    # Получаем продукты в порядке дегустации
    tasting_products = TastingProduct.query.filter_by(tasting_session_id=tasting_session.id).order_by(TastingProduct.order_index).all()
    
    # Создаем Word документ
    doc = Document()
    
    # Поля страницы как на скриншоте
    section = doc.sections[0]
    section.top_margin = Cm(1)
    section.bottom_margin = Cm(0.75)
    section.left_margin = Cm(3)
    section.right_margin = Cm(1.5)
    
    # Настройка стилей по умолчанию
    style = doc.styles['Normal']
    style.font.name = 'Times New Roman'
    style.font.size = Pt(11)
    style.paragraph_format.space_before = Pt(0)
    style.paragraph_format.space_after = Pt(0)
    
    # Заголовок
    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title.add_run('Отчет о внутренней дегустации продукции')
    run.bold = True
    run.font.size = Pt(14)
    run.font.name = 'Times New Roman'
    
    # Пустая строка
    doc.add_paragraph()
    
    # Организация
    org = doc.add_paragraph()
    org.alignment = WD_ALIGN_PARAGRAPH.CENTER
    org_run = org.add_run('Общество с ограниченной ответственностью «МК «Дороничи»')
    org_run.font.size = Pt(11)
    org_run.font.name = 'Times New Roman'
    
    # Пустая строка
    doc.add_paragraph()
    
    # УТВЕРЖДАЮ
    approve = doc.add_paragraph()
    approve.alignment = WD_ALIGN_PARAGRAPH.CENTER
    approve_run = approve.add_run('УТВЕРЖДАЮ')
    approve_run.font.size = Pt(11)
    approve_run.font.name = 'Times New Roman'
    
    # Пустые строки
    doc.add_paragraph()
    doc.add_paragraph()
    
    # Подпись директора (линия)
    director = doc.add_paragraph()
    director.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    director_run = director.add_run('__________________________')
    director_run.font.size = Pt(11)
    director_run.font.name = 'Times New Roman'
    
    # Должность директора
    director2 = doc.add_paragraph()
    director2.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    director2_run = director2.add_run('Исполнительный директор ООО «МК «Дороничи»')
    director2_run.font.size = Pt(11)
    director2_run.font.name = 'Times New Roman'
    
    # ФИО директора
    director3 = doc.add_paragraph()
    director3.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    director3_run = director3.add_run('К.А. Бакин')
    director3_run.font.size = Pt(11)
    director3_run.font.name = 'Times New Roman'
    
    # Дата
    date_str = tasting_session.created_at.strftime('%d.%m.%Y') if tasting_session.created_at else ''
    date_p = doc.add_paragraph()
    date_run = date_p.add_run(date_str)
    date_run.font.size = Pt(11)
    date_run.font.name = 'Times New Roman'
    
    # Цель
    purpose = doc.add_paragraph()
    purpose_label = purpose.add_run('Цель: ')
    purpose_label.bold = True
    purpose_label.font.size = Pt(11)
    purpose_label.font.name = 'Times New Roman'
    purpose_value = purpose.add_run(tasting_session.description or '')
    purpose_value.font.size = Pt(11)
    purpose_value.font.name = 'Times New Roman'
    
    # Пустая строка
    doc.add_paragraph()
    
    # Участники дегустации
    participants = doc.add_paragraph()
    participants_label = participants.add_run('Участники дегустации: ')
    participants_label.bold = True
    participants_label.font.size = Pt(11)
    participants_label.font.name = 'Times New Roman'
    participants_line = participants.add_run(' ' * 2 + '_' * 60)
    participants_line.underline = True
    participants_line.font.size = Pt(11)
    participants_line.font.name = 'Times New Roman'
    
    # Пустая строка
    doc.add_paragraph()
    
    # Результат дегустации
    result = doc.add_paragraph()
    result_label = result.add_run('Результат дегустации: ')
    result_label.bold = True
    result_label.font.size = Pt(11)
    result_label.font.name = 'Times New Roman'
    result_line = result.add_run(' ' * 2 + '_' * 60)
    result_line.underline = True
    result_line.font.size = Pt(11)
    result_line.font.name = 'Times New Roman'
    
    # Пустая строка
    doc.add_paragraph()
    
    # Предмет дегустации
    subject = doc.add_paragraph()
    subject_run = subject.add_run('Предмет дегустации:')
    subject_run.bold = True
    subject_run.font.size = Pt(11)
    subject_run.font.name = 'Times New Roman'
    
    # Значение предмета дегустации (из названия дегустации)
    subject_value_p = doc.add_paragraph()
    subject_value = subject_value_p.add_run(tasting_session.name or '')
    subject_value.font.size = Pt(11)
    subject_value.font.name = 'Times New Roman'
    subject_value.underline = True
    
    # Пустая строка
    doc.add_paragraph()
    
    # Таблица с продуктами
    table = doc.add_table(rows=1, cols=3)
    table.style = 'Table Grid'
    
    # Заголовки таблицы
    header_cells = table.rows[0].cells
    header_cells[0].text = '№'
    header_cells[1].text = 'Наименование продукции'
    header_cells[2].text = 'Количество'
    
    # Форматирование заголовков
    for cell in header_cells:
        for paragraph in cell.paragraphs:
            for run in paragraph.runs:
                run.bold = True
                run.font.size = Pt(12)
                run.font.name = 'Times New Roman'
            paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    # Добавляем продукты
    total_weight = 0
    for idx, tp in enumerate(tasting_products, start=1):
        product = tp.product
        row_cells = table.add_row().cells
        
        # Номер
        row_cells[0].text = str(idx) + '.'
        for paragraph in row_cells[0].paragraphs:
            paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
            for run in paragraph.runs:
                run.font.size = Pt(12)
                run.font.name = 'Times New Roman'
        
        # Название продукта
        row_cells[1].text = product.name
        for paragraph in row_cells[1].paragraphs:
            for run in paragraph.runs:
                run.font.size = Pt(12)
                run.font.name = 'Times New Roman'
        
        # Количество (вес)
        if product.weight_kg:
            weight_str = f"{product.weight_kg:.2f}".replace('.', ',')
            row_cells[2].text = weight_str
            total_weight += product.weight_kg
        else:
            row_cells[2].text = ''
        
        for paragraph in row_cells[2].paragraphs:
            paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
            for run in paragraph.runs:
                run.font.size = Pt(12)
                run.font.name = 'Times New Roman'
    
    # Итого
    total_row = table.add_row().cells
    total_row[0].text = ''
    total_row[1].paragraphs[0].clear()
    total_run = total_row[1].paragraphs[0].add_run('Итого')
    total_run.bold = True
    total_run.font.size = Pt(12)
    total_run.font.name = 'Times New Roman'
    total_weight_str = f"{total_weight:.2f}".replace('.', ',')
    total_row[2].text = total_weight_str
    for paragraph in total_row[2].paragraphs:
        paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
        for run in paragraph.runs:
            run.font.size = Pt(12)
            run.font.name = 'Times New Roman'
    
    # Пустые строки
    doc.add_paragraph()
    doc.add_paragraph()
    
    # Подпись внизу с подчеркиваниями
    signature = doc.add_paragraph()
    sig_run = signature.add_run('_____________ __________________ Борисов С.А.')
    sig_run.font.size = Pt(12)
    sig_run.font.name = 'Times New Roman'
    
    # Сохраняем в память
    output = io.BytesIO()
    doc.save(output)
    output.seek(0)
    
    # Формируем имя файла
    filename = f"Отчет_дегустация_{tasting_session.name}_{date_str.replace('.', '_')}.docx"
    filename = re.sub(r'[<>:"/\\|?*]', '_', filename)
    
    return send_file(output, mimetype='application/vnd.openxmlformats-officedocument.wordprocessingml.document', 
                     as_attachment=True, download_name=filename)

# Функция генерации QR-кода
def generate_qr_code(access_code):
    qr = qrcode.QRCode(version=1, box_size=10, border=5)
    link = _public_tasting_url(access_code)
    qr.add_data(link)
    qr.make(fit=True)
    
    img = qr.make_image(fill_color="black", back_color="white")
    
    # Сохраняем в память
    img_buffer = io.BytesIO()
    img.save(img_buffer, format='PNG')
    img_buffer.seek(0)
    
    # Конвертируем в base64
    img_str = base64.b64encode(img_buffer.getvalue()).decode()
    return f"data:image/png;base64,{img_str}"

# Создание таблиц
def create_tables():
    with app.app_context():
        db.create_all()
        # Авто-добавление недостающих столбцов для SQLite (без Alembic)
        try:
            uri = app.config.get('SQLALCHEMY_DATABASE_URI', '')
            if uri.startswith('sqlite'):
                # tasting_session: tasting_type, criteria_json, task_origin, ended_at
                cols = [row[1] for row in db.session.execute(text('PRAGMA table_info(tasting_session)')).fetchall()]
                if 'tasting_type' not in cols:
                    db.session.execute(text("ALTER TABLE tasting_session ADD COLUMN tasting_type TEXT"))
                if 'criteria_json' not in cols:
                    db.session.execute(text("ALTER TABLE tasting_session ADD COLUMN criteria_json TEXT"))
                if 'task_origin' not in cols:
                    db.session.execute(text("ALTER TABLE tasting_session ADD COLUMN task_origin TEXT"))
                if 'ended_at' not in cols:
                    db.session.execute(text("ALTER TABLE tasting_session ADD COLUMN ended_at DATETIME"))

                # tasting_product: photo_url
                cols = [row[1] for row in db.session.execute(text('PRAGMA table_info(tasting_product)')).fetchall()]
                if 'photo_url' not in cols:
                    db.session.execute(text("ALTER TABLE tasting_product ADD COLUMN photo_url VARCHAR(500)"))

                # tasting_response: ratings_json
                cols = [row[1] for row in db.session.execute(text('PRAGMA table_info(tasting_response)')).fetchall()]
                if 'ratings_json' not in cols:
                    db.session.execute(text("ALTER TABLE tasting_response ADD COLUMN ratings_json TEXT"))
                
                # product: weight_kg
                cols = [row[1] for row in db.session.execute(text('PRAGMA table_info(product)')).fetchall()]
                if 'weight_kg' not in cols:
                    db.session.execute(text("ALTER TABLE product ADD COLUMN weight_kg REAL"))

                # admin: role
                cols = [row[1] for row in db.session.execute(text('PRAGMA table_info(admin)')).fetchall()]
                if 'role' not in cols:
                    db.session.execute(text("ALTER TABLE admin ADD COLUMN role TEXT"))
                db.session.commit()
        except Exception:
            db.session.rollback()
        
        # Создаем админа по умолчанию
        admin = Admin.query.filter_by(username='admin').first()
        if not admin:
            admin = Admin(
                username='admin',
                email='admin@doronichi.com',
                password_hash=generate_password_hash('admin123'),
                role='superadmin'
            )
            db.session.add(admin)
            db.session.commit()
            print("Создан админ: admin / admin123")
        else:
            # Если роль не задана (старые записи), выставим
            if not getattr(admin, 'role', None):
                admin.role = 'superadmin'
                db.session.commit()

        # Обновим роль пустых записей (прочих) на viewer
        try:
            Admin.query.filter((Admin.role == None) | (Admin.role == '')).update({Admin.role: 'viewer'})
            db.session.commit()
        except Exception:
            db.session.rollback()

# Управление пользователями (только суперАдмин)
@app.route('/admin/users')
@login_required
@roles_required('superadmin')
def users_list():
    users = Admin.query.order_by(Admin.created_at.desc()).all()
    return render_template('admin/users.html', users=users)

@app.route('/admin/users/create', methods=['GET', 'POST'])
@login_required
@roles_required('superadmin')
def user_create():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '').strip()
        role = request.form.get('role', 'viewer')
        if not username or not email or not password:
            flash('Заполните обязательные поля', 'error')
            return redirect(url_for('user_create'))
        if Admin.query.filter((Admin.username == username) | (Admin.email == email)).first():
            flash('Пользователь с таким именем или e-mail уже существует', 'error')
            return redirect(url_for('user_create'))
        try:
            u = Admin(username=username, email=email, password_hash=generate_password_hash(password), role=role)
            db.session.add(u)
            db.session.commit()
            flash('Пользователь создан', 'success')
            return redirect(url_for('users_list'))
        except Exception:
            db.session.rollback()
            flash('Ошибка создания пользователя', 'error')
    return render_template('admin/user_form.html', mode='create', user=None)

@app.route('/admin/users/<int:user_id>/edit', methods=['GET', 'POST'])
@login_required
@roles_required('superadmin')
def user_edit(user_id):
    user = Admin.query.get_or_404(user_id)
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip()
        role = request.form.get('role', 'viewer')
        password = request.form.get('password', '').strip()
        if not username or not email:
            flash('Заполните обязательные поля', 'error')
            return redirect(url_for('user_edit', user_id=user_id))
        try:
            if Admin.query.filter(Admin.id != user.id, Admin.username == username).first():
                flash('Имя пользователя занято', 'error')
                return redirect(url_for('user_edit', user_id=user_id))
            if Admin.query.filter(Admin.id != user.id, Admin.email == email).first():
                flash('E-mail занят', 'error')
                return redirect(url_for('user_edit', user_id=user_id))
            user.username = username
            user.email = email
            user.role = role
            if password:
                user.password_hash = generate_password_hash(password)
            db.session.commit()
            flash('Пользователь обновлён', 'success')
            return redirect(url_for('users_list'))
        except Exception:
            db.session.rollback()
            flash('Ошибка обновления пользователя', 'error')
    return render_template('admin/user_form.html', mode='edit', user=user)

def _parse_float_maybe(value: str):
    if value is None:
        return None
    s = str(value).strip().replace(',', '.').replace(' ', '')
    if s == '' or s.lower() in ('nan', 'none'):
        return None
    try:
        return float(s)
    except Exception:
        return None

def import_from_csv(csv_path: str):
    """Импорт продуктов, шаблонов происхождения задач и подсказок комментариев из CSV.
    Ожидается разделитель ';' и заголовки с русскими колонками.
    """
    with app.app_context():
        # Определим кодировку
        encodings = ['utf-8-sig', 'cp1251', 'utf-8']
        reader = None
        for enc in encodings:
            try:
                f = open(csv_path, 'r', encoding=enc, newline='')
                reader = csv.reader(f, delimiter=';')
                headers = next(reader)
                if headers:
                    f.seek(0)
                    break
            except Exception:
                continue
        if reader is None:
            raise RuntimeError('Не удалось открыть CSV с подходящей кодировкой')

        with f:
            header_idx = {}
            suggestions_counter = {}
            origin_counter = {}
            seen_names = set()

            for row in csv.reader(f, delimiter=';'):
                if not row:
                    continue
                # Переобновляем заголовки, если встречаем их в середине файла
                if row[0].strip().startswith('№'):
                    header_idx = {name.strip(): i for i, name in enumerate(row)}
                    continue

                if not header_idx:
                    # Первый реальный заголовок
                    header_idx = {name.strip(): i for i, name in enumerate(row)}
                    continue

                def get(col):
                    i = header_idx.get(col)
                    return row[i].strip() if (i is not None and i < len(row)) else ''

                name = get('Название')
                if not name or name.lower() == 'название':
                    continue

                weight = _parse_float_maybe(get('Вес упак, кг'))
                origin = get('Происхождение задачи/задача')
                comment = get('Комментарии')

                # Продукты (уникальность по имени)
                if name not in seen_names:
                    seen_names.add(name)
                    prod = Product.query.filter_by(name=name).first()
                    if not prod:
                        prod = Product(name=name, weight_kg=weight)
                        db.session.add(prod)
                    else:
                        if weight and (not prod.weight_kg):
                            prod.weight_kg = weight

                # Происхождение задачи — считаем частоты
                if origin:
                    origin_counter[origin] = origin_counter.get(origin, 0) + 1

                # Подсказки комментариев — разбиваем на короткие фразы
                if comment:
                    # Разбиваем по ; . и переносам
                    parts = re.split(r'[;\.\n]+', comment)
                    for p in parts:
                        t = p.strip().strip('"').strip()
                        if 3 <= len(t) <= 80:
                            suggestions_counter[t] = suggestions_counter.get(t, 0) + 1

            # Коммит продуктов
            db.session.commit()

            # Обновляем/создаем шаблоны происхождения задач (топ 30)
            for name, cnt in sorted(origin_counter.items(), key=lambda x: x[1], reverse=True)[:30]:
                tpl = TaskOriginTemplate.query.filter_by(name=name).first()
                if not tpl:
                    tpl = TaskOriginTemplate(name=name, usage_count=cnt)
                    db.session.add(tpl)
                else:
                    tpl.usage_count = max(tpl.usage_count or 0, cnt)

            # Обновляем/создаем подсказки комментариев (топ 100)
            for text_val, cnt in sorted(suggestions_counter.items(), key=lambda x: x[1], reverse=True)[:100]:
                sug = CommentSuggestion.query.filter_by(text=text_val).first()
                if not sug:
                    sug = CommentSuggestion(text=text_val, usage_count=cnt)
                    db.session.add(sug)
                else:
                    sug.usage_count = max(sug.usage_count or 0, cnt)

            db.session.commit()

if __name__ == '__main__':
    create_tables()
    app.run(debug=True, host='0.0.0.0', port=5000)
